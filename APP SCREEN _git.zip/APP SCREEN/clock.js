$(function(){











$("#clock").append("<p id='change'>Click to switch digital clock</p>");
$("#change").click(function(){
    $("#clock").fadeOut(2000);
    // digital clock

    

    setInterval(function(){
        var data= new Date();
       var h_dig=data.getHours();
       var min_dig=data.getMinutes();
      var   sec_dig=data.getSeconds();
     
      $("body").append(`<div id='digital'><div id='dig-hour'>${h_dig}<span>:<span></div><div id='dig-min'>${min_dig}<span>:</span></div><div id='dig-sec'><span id='zero'>0</span>${sec_dig}</div></div>`);

     
    
     



        })
        

      





})





    // analog clock
$("#clock").animate({
    "margin-left":"300px",
    "width":"350px",
   "height":"350px"
},2000)

$(".sec").animate({
"height":"155px"
},2000)

const deg=6;
const hr=document.getElementById("hour");
const min=document.getElementById("minute");
const sec=document.getElementById("second");

setInterval(()=>{
    var day= new Date();
    var hour=day.getHours()*30;
    
    var m=day.getMinutes()*deg;
    
    var s=day.getSeconds()*deg;
    hr.style.transform = `rotateZ(${hour+(m/12)}deg)`;
    min.style.transform = `rotateZ(${m}deg)`;
    sec.style.transform = `rotateZ(${s}deg)`;
    
})


})