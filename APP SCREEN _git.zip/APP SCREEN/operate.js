//console.log("calculaor works!");
var calc=document.getElementById("calc");
calc.addEventListener("click",openCal);
function openCal(){
//alert("you clicked!");
window.location.href="calc.html";

}
var weather=document.getElementById("weather");
weather.addEventListener("click",openWeather);
function openWeather()
{
    window.location.href="weather-app.html";
}

var clock=document.getElementById("clock");
clock.addEventListener("click",openClock);
function openClock()
{
    window.location.href="clock.html";

}



