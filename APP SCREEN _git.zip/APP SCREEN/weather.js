//alert("works!")
const icon=document.querySelector(".icon");
const temp_val=document.querySelector(".temp-val");
const temp_desc=document.querySelector(".temp-desc");
const loc=document.querySelector(".loc");
const notif=document.querySelector(".notif");
const hum=document.querySelector(".hum");

// store the data
const weather_data={
    temperature:{
        value:"18",
        unit:"celsius"
    },
    description:"few clouds",
    iconId:"01d",
    city:"London",
    country:"GB",
   humidity:"10"
    

};





// getting location by API
if("geolocation" in navigator)
{
    navigator.geolocation.getCurrentPosition(setPosition,showError);
}
else{
    notif.style.display="block";
 
    notif.innerHTML=`<p >Browser does not support Geolocation!</p>`;
}

function setPosition(position)
{
    let latitude=position.coords.latitude;
    let longitude=position.coords.longitude;
    getWeather(latitude,longitude);


}

function showError(error)
{
notif.style.display="block";
notif.innerHTML=`<p>${error.message}</p>`
}
// API PROVIDER
const KELVIN=273;
const key= "a59a0a37b57a431d0704ecbdef1f5f26";
function getWeather(latitude,longitude)
{let apı=`http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${key}`;


fetch(apı).then(function(response){
let data=response.json();
return data;
})

.then(
    function(data){
        weather_data.temperature.value=Math.floor(data.main.temp-KELVIN);
       // console.log(">>"+ weather_data.temperature.value);
        weather_data.description=data.weather[0].description;
        weather_data.iconId=data.weather[0].icon;
        weather_data.city=data.name;
        weather_data.country=data.sys.country;
        weather_data.humidity=data.main.humidity;

    }
)

.then(
    function(){
        displayWeather();
    }
)


console.log(apı);
console.log(weather_data.temperature.value);


// changing the type of unit when clicked
temp_val.addEventListener("click",function(){
    if(weather_data.temperature.value===undefined) return ;
    if(weather_data.temperature.unit=="celsius")
   { var fahrenheit=convertToFahren(weather_data.temperature.value);
    fahrenheit=Math.floor(fahrenheit);
    weather_data.temperature.unit="fahrenheit";
    temp_val.innerHTML=`${fahrenheit}°<span>F<span>`;
   }
   else{
    temp_val.innerHTML=`${weather_data.temperature.value}°<span>C<span>`;
    weather_data.temperature.unit="celsius";

   }
})


function displayWeather(){
    icon.innerHTML=`<img src='weather-icons/${weather_data.iconId}.png'>`;
    temp_val.innerHTML=`${weather_data.temperature.value}°<span>C</span>`;
    temp_desc.innerHTML=weather_data.description;
    loc.innerHTML=`${weather_data.city}/${weather_data.country}`;
    hum.innerHTML=`Humidity:${weather_data.humidity}%`;
    }
    function convertToFahren(temp)
    {
        return((9/5*temp)+32);
    }
    





}// displaty wheater