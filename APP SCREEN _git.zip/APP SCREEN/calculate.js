
$(function(){
$("#container").animate({
    "margin-left":"500px"
},2000)
var cells=Array.from(document.getElementsByClassName("cell"));
var screen=document.getElementById("screen");
//console.log(cells);

cells.map(
    pressed=>pressed.addEventListener("click",(e)=>{
 switch(e.target.innerText)
{  case "AC":screen.innerText=" ";
 break;
 case "DEL": 
 if( screen.innerText)
  screen.innerText=screen.innerText.slice(0,-1);
    break;
    case "=": 
   // console.log(typeof(eval( screen.innerText)));
  try{screen.innerText=eval( screen.innerText);

  }catch{
            alert("invalid input!");
  }
        break;
   default:screen.innerText+=e.target.innerText;


}

  
//console.log(text);

    })
)






})  // jq