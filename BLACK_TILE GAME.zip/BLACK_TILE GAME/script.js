//alert("works");

$(function(){
// openining of the page
//globals
var flag=0;
var max=0;
var sum_points=0;
var points=0;
var width=$("#inside").width();

$("#main").css("visibility","hidden");
   $("body").css("background-color","black");
$("#counter1").css({"font-size":"580%","margin-top":"300px","color":"blue"}).css("margin-left","650px");

// time for first counter
var timer=setInterval(decCnt,1000);
var  cnt1_val = localStorage.getItem("counter1") ;
cnt1_val = cnt1_val === null ? 0 : cnt1_val ;
$("#cnt1_val").text(cnt1_val);

function decCnt(start_val)
{
   
  var cnt1_val=parseInt($("#counter1").text()) ;
cnt1_val-=1;
  localStorage.setItem("cnt1_val", cnt1_val)
  $("#counter1").text(cnt1_val);
  
 
  if(cnt1_val===0)
  { window.clearInterval( timer);
   // flag=0;
    $("#main").css("visibility","visible");
    $("body").css("background-color","white");
    $("#counter1").css("visibility","hidden");
  }
}

var t_2=parseInt($("p.time").text());
// game timer
var timer2=setInterval(function dectime2(){

t_2-=1
$("p.time").text(t_2);
//console.log(t_2);
if(t_2===0){
clearInterval(timer2);
$("#main").append("<h2 id='warn'>New High-Score</h2>");
$("#main").append("<div class='parent'><h2 id='again'>F5 to play again</h2></div>");

if(max<=sum_points){
  max=sum_points;


  var loc_Scr=localStorage.getItem("#scr") ;
loc_Scr = loc_Scr === null ? 0 : loc_Scr ;

localStorage.setItem("loc", max)
$("#counter1").text(max);


}
else{console.log("time is up")
//$("#main").append("<h2 id='warn'>time is up</h2>");
}



$(".h-score").text(max);
ran1.fadeOut();
 ran2.fadeOut();
 ran3.fadeOut();

 
$("#again").click(function re () {
  location.reload();
});

// reload f5

 $(window).keydown(function(event) {
  if (event.keyCode === 116) {
    location.reload();
  }
});




 




}// end of t


//console.log("t2:",t_2);


},1000);




// randomly black tiles 0-16

var rand_num1= Math.floor(Math.random()*16)+1;

console.log(rand_num1);

var rand_num2=Math.floor(Math.random()*16)+1;

console.log(rand_num2);
var rand_num3=Math.floor(Math.random()*16)+1;
console.log(rand_num3);

while(rand_num1===rand_num2||rand_num2===rand_num3||rand_num1===rand_num3)
{
   rand_num1= Math.floor(Math.random()*16)+1;

  //console.log(rand_num1);
  
   rand_num2=Math.floor(Math.random()*16)+1;
  
 // console.log(rand_num2);
   rand_num3=Math.floor(Math.random()*16)+1;
  //console.log(rand_num3);
}

var score=parseInt($("#scr").text());


$("#"+ rand_num1).css("background-color","black");

$("#"+ rand_num2).css("background-color","black");
$("#"+ rand_num3).css("background-color","black");





var tile1= $("<td></td>").insertAfter("#"+ rand_num1).hide();



 

var ran1=$("#"+ rand_num1).click(function(){

 tile1.show();
  $("#"+ rand_num1).css("background-color","green").fadeOut();
  addNew();
  flag=1;
  sum_points+=points;
  $(this).text(points+"+")
  $("#scr").text(sum_points);
  width=0;
}) ;



var ran2=$("#"+ rand_num2).click(function(){
  var tile2=$("<td></td>").insertAfter("#"+ rand_num2).hide();
  tile2.show();
  $("#"+ rand_num2).css("background-color","green").fadeOut();
  addNew();
flag=1;
sum_points+=points;
$(this).text(points+"+")
$("#scr").text(sum_points);

width=0;
}) ;





var ran3=$("#"+ rand_num3).click(function(){
  var tile3=$("<td></td>").insertAfter("#"+ rand_num3).hide();
  tile3.show();
  $("#"+ rand_num3).css("background-color","green").fadeOut();
  addNew();
 flag=1;
 sum_points+=points;
 $(this).text(points+"+")
 $("#scr").text(sum_points);
 width=0;
});


function addNew(){
do{
var rand_now1=Math.floor(Math.random()*16)+1;
}while(rand_now1===rand_num1||rand_now1===rand_num2||rand_now1===rand_num3);
$("#"+rand_now1).css("background-color","black")
$("#"+rand_now1).click(function(){
  var tilenew=$("<td></td>").insertAfter("#"+ rand_now1).hide();
  tilenew.show();
  console.log("yes");
$("#"+rand_now1).css("background-color","green").fadeOut()
flag=1;
sum_points+=points;
$(this).text(points+"+")
$("#scr").text(sum_points);
width=0;
addNew();

});


}// end of addNew



//var width=$("#inside").width();

var time_bar=setInterval(function(){

 width+=2;
 console.log(width);

  $("#inside").width(width);
  if(width===230)
  {
    width=0;
   
    $("#inside").width(width);
  
  }

  var rest_len=230-width;
   points=Math.ceil(rest_len/23);
 // console.log("points:",points);

// console.log("sum:",sum_points);
  
},100);


// confety part
console.log("sum",sum_points);



$.confetti.start;
            setTimeout(() => {
             $.confetti.stop();
            }, 2000)
            
        



// end of conffetti
});

