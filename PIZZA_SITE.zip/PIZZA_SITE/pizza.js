




// SEARCH PART
search.addEventListener("click",showBar);
const searchForm=document.getElementById("searchForm");


function showBar( ){
    if( searchForm.style.display!=="block")
  { searchForm.style.display="block";
    searchForm.style.marginLeft="-300px";
}
else{
    searchForm.style.display="none";
}
}   
        // end of search part

// MENU PART
const headContainer=document.getElementsByClassName("container");
const sideMenu=document.getElementById("sideMenu");

const menu_icon=document.getElementById("menu-icon");
menu_icon.addEventListener("click", function(){
  if( sideMenu.style.display==="grid")
    sideMenu.style.display="none";
    else{
        sideMenu.style.display="grid";
    }
  
   
})
// end of menu part


// SHOP BASKET PART
const basket_icon=document.getElementById("shop-icon");
const card_items=document.getElementById("card-Items");
basket_icon.addEventListener("click",function(){
    if(card_items.style.display==="none")
card_items.style.display="inline";
else{
    card_items.style.display="none";
}
})







var item_counter=document.getElementById("counter");
 var count_val=  parseInt(item_counter.innerText)
 var heart_counter=document.getElementById("heartCounter");
 var heart_val=parseInt(heart_counter.innerText );
var heartItems=document.getElementById("heartItems");

// heart icons
var main_heart=document.getElementById("favs");
main_heart.addEventListener("click",function(){
    if(  heartItems.style.display!=="inline")
    heartItems.style.display="inline";
    else{
        heartItems.style.display="none";
    }
})
var hearts=document.getElementsByClassName("feed");
for (item of hearts)
{
    item.addEventListener('click',(e)=>{
        var prnt=e.target.parentNode.parentNode;
        var cpy=prnt.cloneNode(true);
        heartItems.appendChild(cpy);
        heart_val+=1;
        heart_counter.innerText=`${heart_val}`;
    })
}




// basket event

var basket=document.getElementsByClassName("feed basket");
var total_item=document.getElementById("total");
var total_val=parseInt(total_item.innerText);
var sum=0.00;
for (bas of basket)
{   
    bas.addEventListener("click",(e)=>{
       var parent2=e.target.parentNode;
       var parent=e.target.parentNode.parentNode;
       var copy=parent.cloneNode(true);
       var copy2=parent2.cloneNode(true);
       card_items.appendChild(copy2);
       card_items.appendChild(copy);
       
       count_val+=1;
       item_counter.innerText=`${count_val}`;
        var price=document.querySelector(".interact:nth-child(3)");
        var price_val=parseFloat(price.innerText);
        sum=sum+price_val;
        total_item.innerText=sum;
        alert("added to basket!");
    })
}

// get it now button
document.getElementById("getIt").onclick=function(){
    window.location.href="file:///C:/Users/User/Desktop/HOLIDAY/PIZZA_SITE/P%C4%B1zza_site.html#specials";
};


//More button
document.getElementById('learn').onclick = function() {
   window.location.href="https://www.usatoday.com/story/travel/destinations/2013/11/30/best-pizza-in-america/3785309/" ;
}

// contactsender
document.getElementById("sender").onclick=function(){
    alert("your information has sent");

}
// end 




